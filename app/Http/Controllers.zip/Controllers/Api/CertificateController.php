<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Concerns\ChecksPackageLimits;
use App\Http\Controllers\Controller;
use App\Models\Certificate;
use App\Services\PackageAccessService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class CertificateController extends Controller
{
    use ChecksPackageLimits;

    public function __construct(
        private readonly PackageAccessService $packageAccessService
    ) {
    }

    public function index(Request $request): JsonResponse
    {
        $user = $request->user();

        $certificates = $user->certificates()
            ->orderByDesc('is_featured')
            ->orderBy('display_order')
            ->orderByDesc('issue_date')
            ->latest()
            ->get();

        return response()->json([
            'success' => true,
            'certificates' => $certificates,
            'package_limit' => $this->packageLimitData(
                $this->packageAccessService,
                $user,
                'certificates',
                $certificates->count()
            ),
        ]);
    }

    public function store(Request $request): JsonResponse
    {
        $user = $request->user();

        $limitError = $this->packageLimitError(
            $this->packageAccessService,
            $user,
            'certificates',
            $user->certificates()->count(),
            $this->packageAccessService->nextPackage($user) ?? 'Platinum'
        );

        if ($limitError) {
            return $limitError;
        }

        $validated = $request->validate($this->rules(false));
        $validated = $this->prepareData($validated, $request);
        $validated['user_id'] = $user->id;

        if ($request->hasFile('certificate_file')) {
            $file = $request->file('certificate_file');

            $validated['certificate_file'] = $file->store(
                'certificates/' . $user->id,
                'public'
            );

            $validated['original_file_name'] =
                $file->getClientOriginalName();
        }

        $certificate = Certificate::create($validated);

        return response()->json([
            'success' => true,
            'message' => 'Certificate created successfully.',
            'certificate' => $certificate->fresh(),
            'package_limit' => $this->packageLimitData(
                $this->packageAccessService,
                $user,
                'certificates',
                $user->certificates()->count()
            ),
        ], 201);
    }

    public function update(
        Request $request,
        Certificate $certificate
    ): JsonResponse {
        $user = $request->user();

        $this->authorizeOwnership($certificate->user_id, $user->id);

        $validated = $request->validate($this->rules(true));
        $validated = $this->prepareData($validated, $request);

        if (
            $request->boolean('remove_certificate_file') &&
            $certificate->certificate_file
        ) {
            Storage::disk('public')->delete(
                $certificate->certificate_file
            );

            $validated['certificate_file'] = null;
            $validated['original_file_name'] = null;
        }

        if ($request->hasFile('certificate_file')) {
            if ($certificate->certificate_file) {
                Storage::disk('public')->delete(
                    $certificate->certificate_file
                );
            }

            $file = $request->file('certificate_file');

            $validated['certificate_file'] = $file->store(
                'certificates/' . $user->id,
                'public'
            );

            $validated['original_file_name'] =
                $file->getClientOriginalName();
        }

        unset($validated['remove_certificate_file']);

        $certificate->update($validated);

        return response()->json([
            'success' => true,
            'message' => 'Certificate updated successfully.',
            'certificate' => $certificate->fresh(),
        ]);
    }

    public function destroy(
        Request $request,
        Certificate $certificate
    ): JsonResponse {
        $user = $request->user();

        $this->authorizeOwnership($certificate->user_id, $user->id);

        if ($certificate->certificate_file) {
            Storage::disk('public')->delete(
                $certificate->certificate_file
            );
        }

        $certificate->delete();

        return response()->json([
            'success' => true,
            'message' => 'Certificate deleted successfully.',
            'package_limit' => $this->packageLimitData(
                $this->packageAccessService,
                $user,
                'certificates',
                $user->certificates()->count()
            ),
        ]);
    }

    private function rules(bool $updating): array
    {
        return [
            'certificate_name' => 'required|string|max:255',
            'issuing_organization' => 'required|string|max:255',
            'category' => 'nullable|string|max:100',
            'credential_id' => 'nullable|string|max:255',
            'credential_url' => 'nullable|url|max:1000',
            'issue_date' => 'nullable|date',
            'expiry_date' => [
                'nullable',
                'date',
                'after_or_equal:issue_date',
            ],
            'never_expires' => 'nullable|boolean',
            'certificate_file' => [
                'nullable',
                'file',
                'mimes:pdf,jpg,jpeg,png',
                'max:5120',
            ],
            'remove_certificate_file' => $updating
                ? 'nullable|boolean'
                : 'nullable',
            'is_featured' => 'nullable|boolean',
            'display_order' => 'nullable|integer|min:0',
        ];
    }

    private function prepareData(
        array $validated,
        Request $request
    ): array {
        $validated['certificate_name'] =
            trim($validated['certificate_name']);
        $validated['issuing_organization'] =
            trim($validated['issuing_organization']);
        $validated['category'] = isset($validated['category'])
            ? trim($validated['category'])
            : null;
        $validated['credential_id'] = isset($validated['credential_id'])
            ? trim($validated['credential_id'])
            : null;
        $validated['credential_url'] = isset($validated['credential_url'])
            ? trim($validated['credential_url'])
            : null;
        $validated['never_expires'] =
            $request->boolean('never_expires');
        $validated['is_featured'] =
            $request->boolean('is_featured');
        $validated['display_order'] =
            $validated['display_order'] ?? 0;

        if ($validated['never_expires']) {
            $validated['expiry_date'] = null;
        }

        return $validated;
    }

    private function authorizeOwnership(int $ownerId, int $userId): void
    {
        abort_unless(
            $ownerId === $userId,
            403,
            'You are not authorized to access this certificate.'
        );
    }
}