<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Concerns\ChecksPackageLimits;
use App\Http\Controllers\Controller;
use App\Models\Project;
use App\Services\PackageAccessService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class ProjectController extends Controller
{
    use ChecksPackageLimits;

    public function __construct(
        private readonly PackageAccessService $packageAccessService
    ) {
    }

    public function index(Request $request): JsonResponse
    {
        $user = $request->user();

        $projects = $user->projects()
            ->latest()
            ->get();

        return response()->json([
            'success' => true,
            'projects' => $projects,
            'package_limit' => $this->packageLimitData(
                $this->packageAccessService,
                $user,
                'projects',
                $projects->count()
            ),
        ]);
    }

    public function store(Request $request): JsonResponse
    {
        $user = $request->user();

        $limitError = $this->packageLimitError(
            $this->packageAccessService,
            $user,
            'projects',
            $user->projects()->count(),
            $this->packageAccessService->nextPackage($user) ?? 'Platinum'
        );

        if ($limitError) {
            return $limitError;
        }

        $validated = $request->validate([
            'title' => 'required|string|max:255',
            'short_description' => 'nullable|string|max:500',
            'description' => 'nullable|string',
            'image' => 'nullable|string|max:2048',
            'github_url' => 'nullable|url|max:2048',
            'live_url' => 'nullable|url|max:2048',
            'category' => 'nullable|string|max:100',
            'role' => 'nullable|string|max:100',
            'team_size' => 'nullable|string|max:50',
            'technologies' => 'nullable|array',
            'technologies.*' => 'string|max:100',
            'start_date' => 'nullable|date',
            'end_date' => 'nullable|date|after_or_equal:start_date',
            'status' => 'required|in:Planned,In Progress,Completed',
            'featured' => 'nullable|boolean',
        ]);

        $validated['user_id'] = $user->id;
        $validated['featured'] = $request->boolean('featured');

        $project = Project::create($validated);

        return response()->json([
            'success' => true,
            'message' => 'Project created successfully.',
            'project' => $project,
            'package_limit' => $this->packageLimitData(
                $this->packageAccessService,
                $user,
                'projects',
                $user->projects()->count()
            ),
        ], 201);
    }

    public function update(Request $request, Project $project): JsonResponse
    {
        $user = $request->user();

        $this->authorizeOwnership($project->user_id, $user->id);

        $validated = $request->validate([
            'title' => 'required|string|max:255',
            'short_description' => 'nullable|string|max:500',
            'description' => 'nullable|string',
            'image' => 'nullable|string|max:2048',
            'github_url' => 'nullable|url|max:2048',
            'live_url' => 'nullable|url|max:2048',
            'category' => 'nullable|string|max:100',
            'role' => 'nullable|string|max:100',
            'team_size' => 'nullable|string|max:50',
            'technologies' => 'nullable|array',
            'technologies.*' => 'string|max:100',
            'start_date' => 'nullable|date',
            'end_date' => 'nullable|date|after_or_equal:start_date',
            'status' => 'required|in:Planned,In Progress,Completed',
            'featured' => 'nullable|boolean',
        ]);

        $validated['featured'] = $request->boolean('featured');

        $project->update($validated);

        return response()->json([
            'success' => true,
            'message' => 'Project updated successfully.',
            'project' => $project->fresh(),
        ]);
    }

    public function destroy(Request $request, Project $project): JsonResponse
    {
        $user = $request->user();

        $this->authorizeOwnership($project->user_id, $user->id);

        $project->delete();

        return response()->json([
            'success' => true,
            'message' => 'Project deleted successfully.',
            'package_limit' => $this->packageLimitData(
                $this->packageAccessService,
                $user,
                'projects',
                $user->projects()->count()
            ),
        ]);
    }

    private function authorizeOwnership(int $ownerId, int $userId): void
    {
        abort_unless(
            $ownerId === $userId,
            403,
            'You are not authorized to access this project.'
        );
    }
}