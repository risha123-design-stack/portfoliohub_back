<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Controllers\Concerns\ChecksPackageLimits;
use App\Services\PackageAccessService;
use App\Http\Requests\StoreAcademicProjectRequest;
use App\Http\Requests\UpdateAcademicProjectRequest;
use App\Models\AcademicProject;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class AcademicProjectController extends Controller
{
    use ChecksPackageLimits;

    public function __construct(
        private readonly PackageAccessService $packageAccessService
    ) {
    }

    public function index(Request $request): JsonResponse
    {
        $user = auth('api')->user() ?? auth()->user();

        if (!$this->packageAccessService->canAccessProfessionModules($user)) {
            return response()->json(
                $this->packageAccessService->upgradeResponse(
                    'Profession-based modules are available from Gold.',
                    'Gold',
                    ['feature' => 'academic_projects']
                ),
                403
            );
        }

        $projects = $request->user()
            ->academicProjects()
            ->latest()
            ->get();

        return response()->json([
            'success' => true,
            'message' => 'Academic projects retrieved successfully.',
            'data' => $projects,
        ]);
    }

    public function store(
        StoreAcademicProjectRequest $request
    ): JsonResponse {
        $user = $request->user();

        if (!$this->packageAccessService->canAccessProfessionModules($user)) {
            return response()->json(
                $this->packageAccessService->upgradeResponse(
                    'Profession-based modules are available from Gold.',
                    'Gold',
                    ['feature' => 'academic_projects']
                ),
                403
            );
        }

        $requiredPackage = $this->packageAccessService
            ->nextPackage($user) ?? 'Platinum';

        $limitError = $this->packageLimitError(
            $this->packageAccessService,
            $user,
            'academic_projects',
            $user->academicProjects()->count(),
            $requiredPackage
        );

        if ($limitError) {
            return $limitError;
        }

$project = $request->user()
            ->academicProjects()
            ->create($request->validated());

        return response()->json([
            'success' => true,
            'message' => 'Academic project created successfully.',
            'data' => $project,
        ], 201);
    }

    public function show(
        AcademicProject $academicProject,
        Request $request
    ): JsonResponse {
        $user = auth('api')->user() ?? auth()->user();

        if (!$this->packageAccessService->canAccessProfessionModules($user)) {
            return response()->json(
                $this->packageAccessService->upgradeResponse(
                    'Profession-based modules are available from Gold.',
                    'Gold',
                    ['feature' => 'academic_projects']
                ),
                403
            );
        }

        $this->ensureOwnership(
            $academicProject,
            $request
        );

        return response()->json([
            'success' => true,
            'message' => 'Academic project retrieved successfully.',
            'data' => $academicProject,
        ]);
    }

    public function update(
        UpdateAcademicProjectRequest $request,
        AcademicProject $academicProject
    ): JsonResponse {
        $user = auth('api')->user() ?? auth()->user();

        if (!$this->packageAccessService->canAccessProfessionModules($user)) {
            return response()->json(
                $this->packageAccessService->upgradeResponse(
                    'Profession-based modules are available from Gold.',
                    'Gold',
                    ['feature' => 'academic_projects']
                ),
                403
            );
        }

        $this->ensureOwnership(
            $academicProject,
            $request
        );

        $academicProject->update(
            $request->validated()
        );

        return response()->json([
            'success' => true,
            'message' => 'Academic project updated successfully.',
            'data' => $academicProject->fresh(),
        ]);
    }

    public function destroy(
        AcademicProject $academicProject,
        Request $request
    ): JsonResponse {
        $this->ensureOwnership(
            $academicProject,
            $request
        );

        $academicProject->delete();

        return response()->json([
            'success' => true,
            'message' => 'Academic project deleted successfully.',
        ]);
    }

    private function ensureOwnership(
        AcademicProject $academicProject,
        Request $request
    ): void {
        if (
            (int) $academicProject->user_id !==
            (int) $request->user()->id
        ) {
            abort(
                403,
                'You are not authorised to access this academic project.'
            );
        }
    }
}