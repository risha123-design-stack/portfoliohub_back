<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Concerns\ChecksPackageLimits;
use App\Http\Controllers\Controller;
use App\Models\Experience;
use App\Services\PackageAccessService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class ExperienceController extends Controller
{
    use ChecksPackageLimits;

    public function __construct(
        private readonly PackageAccessService $packageAccessService
    ) {
    }

    public function index(Request $request): JsonResponse
    {
        $user = $request->user();

        $experiences = $user->experiences()
            ->orderBy('display_order')
            ->orderByDesc('start_date')
            ->latest()
            ->get();

        return response()->json([
            'success' => true,
            'experiences' => $experiences,
            'package_limit' => $this->packageLimitData(
                $this->packageAccessService,
                $user,
                'experience',
                $experiences->count()
            ),
        ]);
    }

    public function store(Request $request): JsonResponse
    {
        $user = $request->user();

        $limitError = $this->packageLimitError(
            $this->packageAccessService,
            $user,
            'experience',
            $user->experiences()->count(),
            $this->packageAccessService->nextPackage($user) ?? 'Platinum'
        );

        if ($limitError) {
            return $limitError;
        }

        $validated = $request->validate($this->rules());
        $validated = $this->prepareData($validated, $request);
        $validated['user_id'] = $user->id;

        $experience = Experience::create($validated);

        return response()->json([
            'success' => true,
            'message' => 'Experience created successfully.',
            'experience' => $experience,
            'package_limit' => $this->packageLimitData(
                $this->packageAccessService,
                $user,
                'experience',
                $user->experiences()->count()
            ),
        ], 201);
    }

    public function update(
        Request $request,
        Experience $experience
    ): JsonResponse {
        $user = $request->user();

        $this->authorizeOwnership($experience->user_id, $user->id);

        $validated = $request->validate($this->rules());
        $validated = $this->prepareData($validated, $request);

        $experience->update($validated);

        return response()->json([
            'success' => true,
            'message' => 'Experience updated successfully.',
            'experience' => $experience->fresh(),
        ]);
    }

    public function destroy(
        Request $request,
        Experience $experience
    ): JsonResponse {
        $user = $request->user();

        $this->authorizeOwnership($experience->user_id, $user->id);

        $experience->delete();

        return response()->json([
            'success' => true,
            'message' => 'Experience deleted successfully.',
            'package_limit' => $this->packageLimitData(
                $this->packageAccessService,
                $user,
                'experience',
                $user->experiences()->count()
            ),
        ]);
    }

    private function rules(): array
    {
        return [
            'organization_name' => 'required|string|max:255',
            'position_title' => 'required|string|max:255',
            'employment_type' => 'nullable|string|max:100',
            'industry' => 'nullable|string|max:255',
            'location' => 'nullable|string|max:255',
            'location_type' => 'nullable|string|max:100',
            'start_date' => 'nullable|date',
            'end_date' => [
                'nullable',
                'date',
                'after_or_equal:start_date',
            ],
            'currently_working' => 'nullable|boolean',
            'description' => 'nullable|string|max:5000',
            'achievements' => 'nullable|array',
            'achievements.*' => 'string|max:500',
            'skills' => 'nullable|array',
            'skills.*' => 'string|max:100',
            'display_order' => 'nullable|integer|min:0',
        ];
    }

    private function prepareData(
        array $validated,
        Request $request
    ): array {
        $validated['currently_working'] =
            $request->boolean('currently_working');
        $validated['display_order'] = $validated['display_order'] ?? 0;
        $validated['achievements'] = $validated['achievements'] ?? [];
        $validated['skills'] = $validated['skills'] ?? [];

        if ($validated['currently_working']) {
            $validated['end_date'] = null;
        }

        return $validated;
    }

    private function authorizeOwnership(int $ownerId, int $userId): void
    {
        abort_unless(
            $ownerId === $userId,
            403,
            'You are not authorized to access this experience.'
        );
    }
}