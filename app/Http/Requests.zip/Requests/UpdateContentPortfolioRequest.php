<?php

namespace App\Http\Requests;

use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Exceptions\HttpResponseException;

class UpdateContentPortfolioRequest extends FormRequest
{
    /**
     * Determine whether the authenticated user
     * can update this resource.
     */
    public function authorize(): bool
    {
        return auth('api')->check();
    }

    /**
     * Validation rules.
     *
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        return [
            'title' => [
                'required',
                'string',
                'max:255',
            ],

            'platform' => [
                'required',
                'string',
                'max:100',
            ],

            'content_type' => [
                'required',
                'string',
                'max:100',
            ],

            'category' => [
                'nullable',
                'string',
                'max:100',
            ],

            'publish_date' => [
                'nullable',
                'date',
            ],

            'status' => [
                'required',
                'in:Published,Draft,Scheduled,Archived',
            ],

            'content_url' => [
                'nullable',
                'url',
                'max:2048',
            ],

            'thumbnail_url' => [
                'nullable',
                'url',
                'max:2048',
            ],

            'views' => [
                'nullable',
                'integer',
                'min:0',
            ],

            'likes' => [
                'nullable',
                'integer',
                'min:0',
            ],

            'description' => [
                'nullable',
                'string',
                'max:5000',
            ],
        ];
    }

    /**
     * Custom validation messages.
     */
    public function messages(): array
    {
        return [
            'title.required' =>
                'The content title is required.',

            'platform.required' =>
                'The platform is required.',

            'content_type.required' =>
                'The content type is required.',

            'status.required' =>
                'The content status is required.',

            'status.in' =>
                'Invalid content status.',

            'content_url.url' =>
                'Content URL must be valid.',

            'thumbnail_url.url' =>
                'Thumbnail URL must be valid.',

            'views.integer' =>
                'Views must be an integer.',

            'likes.integer' =>
                'Likes must be an integer.',
        ];
    }

    /**
     * Clean request data before validation.
     */
    protected function prepareForValidation(): void
    {
        $this->merge([
            'title' =>
                $this->cleanString(
                    $this->title
                ),

            'platform' =>
                $this->cleanString(
                    $this->platform
                ),

            'content_type' =>
                $this->cleanString(
                    $this->content_type
                ),

            'category' =>
                $this->nullableString(
                    $this->category
                ),

            'publish_date' =>
                $this->nullableString(
                    $this->publish_date
                ),

            'status' =>
                $this->cleanString(
                    $this->status
                ),

            'content_url' =>
                $this->nullableString(
                    $this->content_url
                ),

            'thumbnail_url' =>
                $this->nullableString(
                    $this->thumbnail_url
                ),

            'views' =>
                $this->nullableInteger(
                    $this->views
                ),

            'likes' =>
                $this->nullableInteger(
                    $this->likes
                ),

            'description' =>
                $this->nullableString(
                    $this->description
                ),
        ]);
    }

    /**
     * Standard JSON validation response.
     */
    protected function failedValidation(
        Validator $validator
    ): void {
        throw new HttpResponseException(
            response()->json([
                'success' => false,
                'message' =>
                    'Validation failed.',
                'errors' =>
                    $validator->errors(),
            ], 422)
        );
    }

    private function cleanString(
        mixed $value
    ): string {
        return trim(
            (string) ($value ?? '')
        );
    }

    private function nullableString(
        mixed $value
    ): ?string {
        if ($value === null) {
            return null;
        }

        $value = trim(
            (string) $value
        );

        return $value === ''
            ? null
            : $value;
    }

    private function nullableInteger(
        mixed $value
    ): ?int {
        if (
            $value === null ||
            $value === ''
        ) {
            return null;
        }

        return (int) $value;
    }
}