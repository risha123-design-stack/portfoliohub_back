<?php

namespace App\Http\Requests;

use Illuminate\Contracts\Validation\ValidationRule;
use Illuminate\Foundation\Http\FormRequest;

class UpdateStudentCertificationRequest extends FormRequest{
    public function authorize(): bool
    {
        return true;
    }

    protected function prepareForValidation(): void
    {
        $this->merge([

            'title' => trim((string) $this->title),

            'provider' => trim((string) $this->provider),

            'category' => trim((string) $this->category),

            'credential_id' => $this->credential_id === ''
                ? null
                : trim((string) $this->credential_id),

            'skills' => $this->skills === ''
                ? null
                : trim((string) $this->skills),

            'description' => $this->description === ''
                ? null
                : trim((string) $this->description),

            'issue_date' => $this->issue_date === ''
                ? null
                : $this->issue_date,

            'expiry_date' => $this->expiry_date === ''
                ? null
                : $this->expiry_date,

        ]);
    }

    public function rules(): array
    {
        return [

            'title' => 'required|string|max:255',

            'provider' => 'required|string|max:255',

            'category' => 'required|string|max:255',

            'issue_date' => 'nullable|date',

            'expiry_date' => 'nullable|date|after_or_equal:issue_date',

            'credential_id' => 'nullable|string|max:255',

            'status' => 'required|in:Completed,In Progress,Expired',

            'skills' => 'nullable|string|max:500',

            'description' => 'nullable|string|max:5000',

        ];
    }
}