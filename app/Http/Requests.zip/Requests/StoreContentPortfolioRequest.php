<?php

namespace App\Http\Requests;

use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Exceptions\HttpResponseException;

class StoreContentPortfolioRequest extends FormRequest
{
    /**
     * Determine whether the authenticated user
     * is allowed to perform this request.
     */
    public function authorize(): bool
    {
        return auth('api')->check();
    }

    /**
     * Validation rules for creating
     * a content portfolio record.
     *
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        return [
            'title' => [
                'required',
                'string',
                'max:255',
            ],

            'platform' => [
                'required',
                'string',
                'max:100',
            ],

            'content_type' => [
                'required',
                'string',
                'max:100',
            ],

            'category' => [
                'nullable',
                'string',
                'max:100',
            ],

            'publish_date' => [
                'nullable',
                'date',
            ],

            'status' => [
                'required',
                'string',
                'in:Published,Draft,Scheduled,Archived',
            ],

            'content_url' => [
                'nullable',
                'url',
                'max:2048',
            ],

            'thumbnail_url' => [
                'nullable',
                'url',
                'max:2048',
            ],

            'views' => [
                'nullable',
                'integer',
                'min:0',
            ],

            'likes' => [
                'nullable',
                'integer',
                'min:0',
            ],

            'description' => [
                'nullable',
                'string',
                'max:5000',
            ],
        ];
    }

    /**
     * Custom validation messages.
     *
     * @return array<string, string>
     */
    public function messages(): array
    {
        return [
            'title.required' =>
                'The content title is required.',

            'title.max' =>
                'The content title cannot exceed 255 characters.',

            'platform.required' =>
                'The platform is required.',

            'platform.max' =>
                'The platform cannot exceed 100 characters.',

            'content_type.required' =>
                'The content type is required.',

            'content_type.max' =>
                'The content type cannot exceed 100 characters.',

            'category.max' =>
                'The category cannot exceed 100 characters.',

            'publish_date.date' =>
                'The publish date must be a valid date.',

            'status.required' =>
                'The content status is required.',

            'status.in' =>
                'The selected content status is invalid.',

            'content_url.url' =>
                'The content URL must be a valid URL.',

            'thumbnail_url.url' =>
                'The thumbnail URL must be a valid URL.',

            'views.integer' =>
                'The views value must be a whole number.',

            'views.min' =>
                'The views value cannot be negative.',

            'likes.integer' =>
                'The likes value must be a whole number.',

            'likes.min' =>
                'The likes value cannot be negative.',

            'description.max' =>
                'The description cannot exceed 5000 characters.',
        ];
    }

    /**
     * Prepare incoming values before validation.
     */
    protected function prepareForValidation(): void
    {
        $this->merge([
            'title' => $this->cleanString(
                $this->input('title')
            ),

            'platform' => $this->cleanString(
                $this->input('platform')
            ),

            'content_type' => $this->cleanString(
                $this->input('content_type')
            ),

            'category' => $this->nullableString(
                $this->input('category')
            ),

            'publish_date' => $this->nullableString(
                $this->input('publish_date')
            ),

            'status' => $this->cleanString(
                $this->input('status', 'Published')
            ),

            'content_url' => $this->nullableString(
                $this->input('content_url')
            ),

            'thumbnail_url' => $this->nullableString(
                $this->input('thumbnail_url')
            ),

            'views' => $this->nullableInteger(
                $this->input('views')
            ),

            'likes' => $this->nullableInteger(
                $this->input('likes')
            ),

            'description' => $this->nullableString(
                $this->input('description')
            ),
        ]);
    }

    /**
     * Return a consistent JSON response
     * when validation fails.
     */
    protected function failedValidation(
        Validator $validator
    ): void {
        throw new HttpResponseException(
            response()->json([
                'success' => false,
                'message' =>
                    'The provided content portfolio data is invalid.',
                'errors' => $validator->errors(),
            ], 422)
        );
    }

    private function cleanString(
        mixed $value
    ): string {
        return trim((string) ($value ?? ''));
    }

    private function nullableString(
        mixed $value
    ): ?string {
        if ($value === null) {
            return null;
        }

        $cleanedValue = trim((string) $value);

        return $cleanedValue === ''
            ? null
            : $cleanedValue;
    }

    private function nullableInteger(
        mixed $value
    ): ?int {
        if (
            $value === null ||
            $value === ''
        ) {
            return null;
        }

        return filter_var(
            $value,
            FILTER_VALIDATE_INT
        ) !== false
            ? (int) $value
            : $value;
    }
}