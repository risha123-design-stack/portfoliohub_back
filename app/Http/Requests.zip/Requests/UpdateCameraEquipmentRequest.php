<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class UpdateCameraEquipmentRequest extends FormRequest
{
    protected function prepareForValidation(): void
    {
        $this->merge([
            'name' => is_string($this->name)
                ? trim($this->name)
                : $this->name,

            'brand' => is_string($this->brand)
                ? trim($this->brand)
                : $this->brand,

            'model' => is_string($this->model)
                ? trim($this->model)
                : $this->model,

            'description' => is_string($this->description)
                ? trim($this->description)
                : $this->description,
        ]);

        if ($this->description === '') {
            $this->merge([
                'description' => null,
            ]);
        }

        if ($this->purchase_year === '') {
            $this->merge([
                'purchase_year' => null,
            ]);
        }
    }

    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'name' => [
                'required',
                'string',
                'max:255',
            ],

            'type' => [
                'required',
                'in:Camera,Lens,Lighting,Tripod,Drone,Accessory',
            ],

            'brand' => [
                'required',
                'string',
                'max:255',
            ],

            'model' => [
                'required',
                'string',
                'max:255',
            ],

            'condition' => [
                'required',
                'in:Excellent,Good,Fair,Needs Repair',
            ],

            'purchase_year' => [
                'nullable',
                'integer',
                'min:1900',
                'max:' . now()->year,
            ],

            'status' => [
                'required',
                'in:Available,In Use,Under Maintenance,Unavailable',
            ],

            'description' => [
                'nullable',
                'string',
                'max:3000',
            ],
        ];
    }

    public function messages(): array
    {
        return [
            'name.required' =>
                'Equipment name is required.',

            'type.in' =>
                'Please select a valid equipment type.',

            'brand.required' =>
                'Brand is required.',

            'model.required' =>
                'Model is required.',

            'condition.in' =>
                'Please select a valid equipment condition.',

            'purchase_year.integer' =>
                'Purchase year must be a valid year.',

            'purchase_year.min' =>
                'Purchase year cannot be earlier than 1900.',

            'purchase_year.max' =>
                'Purchase year cannot be in the future.',

            'status.in' =>
                'Please select a valid equipment status.',
        ];
    }
}