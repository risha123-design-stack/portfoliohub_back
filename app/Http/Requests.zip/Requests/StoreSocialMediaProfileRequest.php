<?php

namespace App\Http\Requests;

use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Exceptions\HttpResponseException;

class StoreSocialMediaProfileRequest extends FormRequest
{
    /**
     * Determine whether the user is authorized.
     */
    public function authorize(): bool
    {
        return auth('api')->check();
    }

    /**
     * Validation rules.
     *
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        return [
            'platform' => [
                'required',
                'string',
                'max:100',
            ],

            'username' => [
                'required',
                'string',
                'max:150',
            ],

            'profile_url' => [
                'required',
                'url',
                'max:2048',
            ],

            'followers' => [
                'nullable',
                'integer',
                'min:0',
            ],

            'content_type' => [
                'nullable',
                'string',
                'max:100',
            ],

            'status' => [
                'required',
                'in:Active,Inactive,Archived',
            ],

            'description' => [
                'nullable',
                'string',
                'max:5000',
            ],
        ];
    }

    /**
     * Validation messages.
     */
    public function messages(): array
    {
        return [

            'platform.required' =>
                'Platform is required.',

            'platform.max' =>
                'Platform cannot exceed 100 characters.',

            'username.required' =>
                'Username is required.',

            'username.max' =>
                'Username cannot exceed 150 characters.',

            'profile_url.required' =>
                'Profile URL is required.',

            'profile_url.url' =>
                'Profile URL must be a valid URL.',

            'followers.integer' =>
                'Followers must be an integer.',

            'followers.min' =>
                'Followers cannot be negative.',

            'content_type.max' =>
                'Content type cannot exceed 100 characters.',

            'status.required' =>
                'Status is required.',

            'status.in' =>
                'Invalid status selected.',

            'description.max' =>
                'Description cannot exceed 5000 characters.',
        ];
    }

    /**
     * Clean request values.
     */
    protected function prepareForValidation(): void
    {
        $this->merge([

            'platform' =>
                $this->cleanString($this->platform),

            'username' =>
                $this->cleanString($this->username),

            'profile_url' =>
                $this->nullableString($this->profile_url),

            'followers' =>
                $this->nullableInteger($this->followers),

            'content_type' =>
                $this->nullableString($this->content_type),

            'status' =>
                $this->cleanString(
                    $this->status ?? 'Active'
                ),

            'description' =>
                $this->nullableString($this->description),
        ]);
    }

    /**
     * Return JSON validation response.
     */
    protected function failedValidation(
        Validator $validator
    ): void {

        throw new HttpResponseException(

            response()->json([
                'success' => false,
                'message' => 'Validation failed.',
                'errors' => $validator->errors(),
            ], 422)

        );
    }

    private function cleanString(
        mixed $value
    ): string {

        return trim(
            (string) ($value ?? '')
        );
    }

    private function nullableString(
        mixed $value
    ): ?string {

        if ($value === null) {
            return null;
        }

        $value = trim((string) $value);

        return $value === ''
            ? null
            : $value;
    }

    private function nullableInteger(
        mixed $value
    ): ?int {

        if (
            $value === null ||
            $value === ''
        ) {
            return null;
        }

        return (int) $value;
    }
}