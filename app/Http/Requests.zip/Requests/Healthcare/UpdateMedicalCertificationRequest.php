<?php

namespace App\Http\Requests\Healthcare;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class UpdateMedicalCertificationRequest extends FormRequest
{
    public function authorize(): bool
    {
        return auth('api')->check();
    }

    protected function prepareForValidation(): void
    {
        $this->merge([
            'title' => is_string($this->title)
                ? trim($this->title)
                : $this->title,

            'issuer' => is_string($this->issuer)
                ? trim($this->issuer)
                : $this->issuer,

            'category' => is_string($this->category)
                ? trim($this->category)
                : $this->category,

            'description' => is_string($this->description)
                ? trim($this->description)
                : $this->description,
        ]);
    }

    public function rules(): array
    {
        return [
            'title' => [
                'required',
                'string',
                'max:255',
            ],

            'issuer' => [
                'required',
                'string',
                'max:255',
            ],

            'category' => [
                'required',
                'string',
                'max:255',
            ],

            'issueDate' => [
                'nullable',
                'date',
            ],

            'expiryDate' => [
                'nullable',
                'date',
                'after_or_equal:issueDate',
            ],

            'status' => [
                'required',
                Rule::in([
                    'Active',
                    'Expired',
                    'Expiring Soon',
                ]),
            ],

            'description' => [
                'nullable',
                'string',
                'max:5000',
            ],
        ];
    }

    public function messages(): array
    {
        return [
            'title.required' =>
                'Certification title is required.',

            'issuer.required' =>
                'Issuing organization is required.',

            'category.required' =>
                'Certification category is required.',

            'expiryDate.after_or_equal' =>
                'Expiry date must be the same as or after the issue date.',

            'status.in' =>
                'Certification status must be Active, Expired, or Expiring Soon.',
        ];
    }
}