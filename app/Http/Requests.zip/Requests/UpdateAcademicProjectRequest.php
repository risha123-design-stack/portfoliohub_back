<?php

namespace App\Http\Requests;

use Illuminate\Contracts\Validation\ValidationRule;
use Illuminate\Foundation\Http\FormRequest;

class UpdateAcademicProjectRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Prepare the data for validation.
     */
    protected function prepareForValidation(): void
    {
        $this->merge([
            'title' => trim((string) $this->title),
            'course' => trim((string) $this->course),
            'subject' => trim((string) $this->subject),

            'grade' => $this->grade === ''
                ? null
                : trim((string) $this->grade),

            'technologies' => trim((string) $this->technologies),

            'description' => $this->description === ''
                ? null
                : trim((string) $this->description),

            'start_date' => $this->start_date === ''
                ? null
                : $this->start_date,

            'end_date' => $this->end_date === ''
                ? null
                : $this->end_date,
        ]);
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [

            'title' => 'required|string|max:255',

            'course' => 'required|string|max:255',

            'subject' => 'required|string|max:255',

            'project_type' => 'required|in:Individual Project,Group Project,Research Project,Capstone Project',

            'start_date' => 'nullable|date',

            'end_date' => 'nullable|date|after_or_equal:start_date',

            'status' => 'required|in:Planned,In Progress,Completed,On Hold',

            'grade' => 'nullable|string|max:20',

            'technologies' => 'required|string|max:500',

            'description' => 'nullable|string|max:5000',

        ];
    }
}