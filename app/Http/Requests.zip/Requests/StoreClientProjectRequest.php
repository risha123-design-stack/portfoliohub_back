<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class StoreClientProjectRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    protected function prepareForValidation(): void
    {
        $budget = $this->budget;

        if (is_string($budget)) {
            $budget = preg_replace('/[^0-9.]/', '', $budget);
        }

        $this->merge([
            'title' => trim((string) $this->title),

            'client' => trim((string) $this->client),

            'category' => trim((string) $this->category),

            'budget' => $budget === '' || $budget === null
                ? null
                : $budget,

            'deadline' => $this->deadline === ''
                ? null
                : $this->deadline,

            'description' => $this->description === ''
                ? null
                : trim((string) $this->description),
        ]);
    }

    public function rules(): array
    {
        return [
            'title' => [
                'required',
                'string',
                'max:255',
            ],

            'client' => [
                'required',
                'string',
                'max:255',
            ],

            'category' => [
                'required',
                'string',
                'max:255',
            ],

            'budget' => [
                'nullable',
                'numeric',
                'min:0',
                'max:9999999999.99',
            ],

            'deadline' => [
                'nullable',
                'date',
            ],

            'status' => [
                'required',
                Rule::in([
                    'In Progress',
                    'Completed',
                    'Cancelled',
                ]),
            ],

            'description' => [
                'nullable',
                'string',
                'max:5000',
            ],
        ];
    }

    public function messages(): array
    {
        return [
            'title.required' =>
                'Project title is required.',

            'client.required' =>
                'Client name is required.',

            'category.required' =>
                'Project category is required.',

            'budget.numeric' =>
                'Budget must be a valid amount.',

            'status.in' =>
                'Please select a valid project status.',
        ];
    }
}