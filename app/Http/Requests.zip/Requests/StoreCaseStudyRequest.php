<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class StoreCaseStudyRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [

            'title' => 'required|string|max:255',

            'category' => 'required|string|max:255',

            'client' => 'required|string|max:255',

            'duration' => 'nullable|string|max:255',

            'tools' => 'nullable|string|max:255',

            'status' => [
                'required',
                Rule::in([
                    'Completed',
                    'In Progress',
                    'Planned'
                ])
            ],

            'description' => 'nullable|string',
        ];
    }
}