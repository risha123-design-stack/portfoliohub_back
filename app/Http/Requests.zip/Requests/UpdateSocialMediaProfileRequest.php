<?php

namespace App\Http\Requests;

use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Exceptions\HttpResponseException;

class UpdateSocialMediaProfileRequest extends FormRequest
{
    /**
     * Determine whether the authenticated user
     * can update this social media profile.
     */
    public function authorize(): bool
    {
        return auth('api')->check();
    }

    /**
     * Validation rules.
     *
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        return [
            'platform' => [
                'required',
                'string',
                'max:100',
            ],

            'username' => [
                'required',
                'string',
                'max:150',
            ],

            'profile_url' => [
                'required',
                'url',
                'max:2048',
            ],

            'followers' => [
                'nullable',
                'integer',
                'min:0',
            ],

            'content_type' => [
                'nullable',
                'string',
                'max:100',
            ],

            'status' => [
                'required',
                'string',
                'in:Active,Inactive,Archived',
            ],

            'description' => [
                'nullable',
                'string',
                'max:5000',
            ],
        ];
    }

    /**
     * Custom validation messages.
     *
     * @return array<string, string>
     */
    public function messages(): array
    {
        return [
            'platform.required' =>
                'Platform is required.',

            'platform.string' =>
                'Platform must be valid text.',

            'platform.max' =>
                'Platform cannot exceed 100 characters.',

            'username.required' =>
                'Username is required.',

            'username.string' =>
                'Username must be valid text.',

            'username.max' =>
                'Username cannot exceed 150 characters.',

            'profile_url.required' =>
                'Profile URL is required.',

            'profile_url.url' =>
                'Profile URL must be a valid URL.',

            'profile_url.max' =>
                'Profile URL cannot exceed 2048 characters.',

            'followers.integer' =>
                'Followers must be a whole number.',

            'followers.min' =>
                'Followers cannot be negative.',

            'content_type.string' =>
                'Content type must be valid text.',

            'content_type.max' =>
                'Content type cannot exceed 100 characters.',

            'status.required' =>
                'Status is required.',

            'status.in' =>
                'The selected status is invalid.',

            'description.string' =>
                'Description must be valid text.',

            'description.max' =>
                'Description cannot exceed 5000 characters.',
        ];
    }

    /**
     * Prepare request values before validation.
     */
    protected function prepareForValidation(): void
    {
        $this->merge([
            'platform' => $this->cleanString(
                $this->input('platform')
            ),

            'username' => $this->cleanString(
                $this->input('username')
            ),

            'profile_url' => $this->nullableString(
                $this->input('profile_url')
            ),

            'followers' => $this->nullableInteger(
                $this->input('followers')
            ),

            'content_type' => $this->nullableString(
                $this->input('content_type')
            ),

            'status' => $this->cleanString(
                $this->input('status', 'Active')
            ),

            'description' => $this->nullableString(
                $this->input('description')
            ),
        ]);
    }

    /**
     * Return a consistent JSON response
     * when validation fails.
     */
    protected function failedValidation(
        Validator $validator
    ): void {
        throw new HttpResponseException(
            response()->json([
                'success' => false,
                'message' =>
                    'The provided social media profile data is invalid.',
                'errors' => $validator->errors(),
            ], 422)
        );
    }

    private function cleanString(
        mixed $value
    ): string {
        return trim(
            (string) ($value ?? '')
        );
    }

    private function nullableString(
        mixed $value
    ): ?string {
        if ($value === null) {
            return null;
        }

        $cleanedValue = trim(
            (string) $value
        );

        return $cleanedValue === ''
            ? null
            : $cleanedValue;
    }

    private function nullableInteger(
        mixed $value
    ): mixed {
        if (
            $value === null ||
            $value === ''
        ) {
            return null;
        }

        return filter_var(
            $value,
            FILTER_VALIDATE_INT
        ) !== false
            ? (int) $value
            : $value;
    }
}