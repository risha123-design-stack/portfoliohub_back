<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class UpdateTeachingSubjectRequest extends FormRequest
{
    protected function prepareForValidation(): void
    {
        $this->merge([
            'subject' => $this->subject
                ? trim($this->subject)
                : null,

            'grade' => $this->grade
                ? trim($this->grade)
                : null,

            'medium' => $this->medium
                ? trim($this->medium)
                : null,

            'experience' => $this->experience
                ? trim($this->experience)
                : null,

            'description' => $this->description
                ? trim($this->description)
                : null,
        ]);
    }

    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'subject' => [
                'required',
                'string',
                'max:255',
            ],

            'grade' => [
                'required',
                'string',
                'max:100',
            ],

            'medium' => [
                'required',
                'in:English,Tamil,Sinhala',
            ],

            'experience' => [
                'nullable',
                'string',
                'max:100',
            ],

            'description' => [
                'nullable',
                'string',
                'max:2000',
            ],
        ];
    }

    public function messages(): array
    {
        return [
            'subject.required' =>
                'Subject name is required.',

            'grade.required' =>
                'Grade is required.',

            'medium.required' =>
                'Teaching medium is required.',

            'medium.in' =>
                'Medium must be English, Tamil, or Sinhala.',
        ];
    }
}