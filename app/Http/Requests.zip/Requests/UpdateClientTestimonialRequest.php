<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class UpdateClientTestimonialRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'client_name' => [
                'sometimes',
                'required',
                'string',
                'max:255',
            ],

            'company' => [
                'sometimes',
                'required',
                'string',
                'max:255',
            ],

            'project' => [
                'sometimes',
                'required',
                'string',
                'max:255',
            ],

            'rating' => [
                'sometimes',
                'required',
                'integer',
                'between:1,5',
            ],

            'testimonial_date' => [
                'nullable',
                'date',
            ],

            'status' => [
                'sometimes',
                'required',
                Rule::in([
                    'Published',
                    'Draft',
                    'Hidden',
                ]),
            ],

            'testimonial' => [
                'sometimes',
                'required',
                'string',
                'max:5000',
            ],
        ];
    }

    public function messages(): array
    {
        return [
            'client_name.required' =>
                'Client name is required.',

            'company.required' =>
                'Company is required.',

            'project.required' =>
                'Project name is required.',

            'rating.required' =>
                'Rating is required.',

            'rating.integer' =>
                'Rating must be a whole number.',

            'rating.between' =>
                'Rating must be between 1 and 5.',

            'testimonial_date.date' =>
                'Testimonial date must be a valid date.',

            'status.required' =>
                'Status is required.',

            'status.in' =>
                'Status must be Published, Draft, or Hidden.',

            'testimonial.required' =>
                'Testimonial content is required.',
        ];
    }
}