<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StoreTechStackRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [

            'category' => [
                'required',
                'string',
                'max:100'
            ],

            'technology' => [
                'required',
                'string',
                'max:255'
            ],

            'level' => [
                'required',
                'string',
                'max:100'
            ],

            'experience' => [
                'required',
                'string',
                'max:100'
            ],

        ];
    }
}