<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StorePhotographyPortfolioRequest extends FormRequest
{
    protected function prepareForValidation(): void
    {
        $this->merge([
            'title' => is_string($this->title)
                ? trim($this->title)
                : $this->title,

            'category' => is_string($this->category)
                ? trim($this->category)
                : $this->category,

            'location' => is_string($this->location)
                ? trim($this->location)
                : $this->location,

            'camera' => is_string($this->camera)
                ? trim($this->camera)
                : $this->camera,

            'description' => is_string($this->description)
                ? trim($this->description)
                : $this->description,
        ]);

        if ($this->project_date === '') {
            $this->merge([
                'project_date' => null,
            ]);
        }

        if ($this->camera === '') {
            $this->merge([
                'camera' => null,
            ]);
        }

        if ($this->description === '') {
            $this->merge([
                'description' => null,
            ]);
        }
    }

    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'title' => [
                'required',
                'string',
                'max:255',
            ],

            'category' => [
                'required',
                'string',
                'max:150',
            ],

            'location' => [
                'required',
                'string',
                'max:255',
            ],

            'project_date' => [
                'nullable',
                'date',
            ],

            'camera' => [
                'nullable',
                'string',
                'max:255',
            ],

            'status' => [
                'required',
                'in:Published,Draft',
            ],

            'description' => [
                'nullable',
                'string',
                'max:5000',
            ],
        ];
    }

    public function messages(): array
    {
        return [
            'title.required' =>
                'Portfolio project title is required.',

            'category.required' =>
                'Photography category is required.',

            'location.required' =>
                'Project location is required.',

            'project_date.date' =>
                'Please provide a valid project date.',

            'status.required' =>
                'Portfolio status is required.',

            'status.in' =>
                'Status must be Published or Draft.',
        ];
    }
}