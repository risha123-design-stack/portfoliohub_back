<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StoreWorkshopRequest extends FormRequest
{
    protected function prepareForValidation(): void
    {
        $this->merge([

            'title' =>
                $this->title
                    ? trim($this->title)
                    : null,

            'organizer' =>
                $this->organizer
                    ? trim($this->organizer)
                    : null,

            'location' =>
                $this->location
                    ? trim($this->location)
                    : null,

            'description' =>
                $this->description
                    ? trim($this->description)
                    : null,

        ]);
    }

    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [

            'title' => [
                'required',
                'string',
                'max:255',
            ],

            'organizer' => [
                'required',
                'string',
                'max:255',
            ],

            'location' => [
                'required',
                'string',
                'max:255',
            ],

            'workshop_date' => [
                'required',
                'date',
            ],

            'certificate' => [
                'required',
                'in:Yes,No',
            ],

            'description' => [
                'nullable',
                'string',
            ],

        ];
    }

    public function messages(): array
    {
        return [

            'title.required' =>
                'Workshop title is required.',

            'organizer.required' =>
                'Organizer is required.',

            'location.required' =>
                'Location is required.',

            'workshop_date.required' =>
                'Workshop date is required.',

        ];
    }
}