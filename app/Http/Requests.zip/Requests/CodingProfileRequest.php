<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class CodingProfileRequest extends FormRequest
{
    public function authorize(): bool
    {
        return auth()->check();
    }

    public function rules(): array
    {
        $codingProfile = $this->route('coding_profile');

        $codingProfileId = is_object($codingProfile)
            ? $codingProfile->id
            : $codingProfile;

        return [
            'platform' => [
                'required',
                'string',
                'max:50',
                Rule::in([
                    'LeetCode',
                    'HackerRank',
                    'Codeforces',
                    'CodeChef',
                    'GitHub',
                ]),
            ],

            'username' => [
                'required',
                'string',
                'max:100',

                Rule::unique('coding_profiles', 'username')
                    ->where(function ($query) {
                        return $query
                            ->where('user_id', auth()->id())
                            ->where('platform', $this->input('platform'));
                    })
                    ->ignore($codingProfileId),
            ],

            'rating' => [
                'nullable',
                'string',
                'max:50',
            ],

            'solved' => [
                'nullable',
                'integer',
                'min:0',
            ],

            'rank' => [
                'nullable',
                'string',
                'max:100',
            ],

            'stars' => [
                'nullable',
                'integer',
                'min:0',
            ],

            'profileUrl' => [
                'required',
                'url',
                'max:2048',
            ],
        ];
    }

    public function messages(): array
    {
        return [
            'platform.required' => 'Platform is required.',
            'platform.in' => 'Please select a valid coding platform.',

            'username.required' => 'Username is required.',
            'username.unique' =>
                'This coding profile has already been added.',

            'solved.integer' =>
                'Problems solved must be a valid number.',

            'solved.min' =>
                'Problems solved cannot be negative.',

            'stars.integer' =>
                'Stars must be a valid number.',

            'stars.min' =>
                'Stars cannot be negative.',

            'profileUrl.required' =>
                'Profile URL is required.',

            'profileUrl.url' =>
                'Please enter a valid profile URL.',
        ];
    }
}