<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class UpdateDesignToolRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [

            'tool' => [
                'sometimes',
                'required',
                'string',
                'max:255',
            ],

            'category' => [
                'sometimes',
                'required',
                Rule::in([
                    'UI Design',
                    'UX Design',
                    'Graphics',
                    'Prototyping',
                    'Animation',
                ]),
            ],

            'level' => [
                'sometimes',
                'required',
                Rule::in([
                    'Beginner',
                    'Intermediate',
                    'Advanced',
                    'Expert',
                ]),
            ],

            'experience' => [
                'nullable',
                'string',
                'max:255',
            ],

            'description' => [
                'nullable',
                'string',
            ],

        ];
    }
}