<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class UpdateCaseStudyRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [

            'title' => 'sometimes|required|string|max:255',

            'category' => 'sometimes|required|string|max:255',

            'client' => 'sometimes|required|string|max:255',

            'duration' => 'nullable|string|max:255',

            'tools' => 'nullable|string|max:255',

            'status' => [
                'sometimes',
                'required',
                Rule::in([
                    'Completed',
                    'In Progress',
                    'Planned'
                ])
            ],

            'description' => 'nullable|string',
        ];
    }
}